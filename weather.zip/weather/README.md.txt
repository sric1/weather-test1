
# Weatheer API

## Build Project from Source
Run the below command from the parent directory of the project.
``` 
./gradlew clean build
 ```


java -jar build/libs/WeatherAPIWrappers.jar
```

##Docker
To build the jar:
`./gradlew clean build`  (or)

 gradlew build

To build the docker image, from the project dir run:
`docker build -t buildimagename`.

Example: 
docker build -t weatherapiv1`.


To run the docker container locally
------------------------------------
`docker run --rm --name=buildimagename -e "OPEN_WEATHER_URL=open_url" -e "API_JAR_FLAGS=your_jar_flags" -e "API_PORT=server API port" -p 8080:8080 buildimagename`

Example: 
`docker run --rm --name=weatherapiv1 -e "OPEN_WEATHER_URL=https://api.open-meteo.com/v1/forecast" -e "API_JAR_FLAGS=-server -Xms400m -Xmx400m -XX:MaxMetaspaceSize=1g -Dorg.slf4j.simpleLogger.log.com.zaxxer.hikari=debug" -e "API_PORT=8080" -p 8080:8080 weatherapiv1`

To check the container running
docker ps


BASIC Project steps-
----------------------------
Add gradle jar and  gradle wrapper properties as 5.4

distributionUrl=https\://services.gradle.org/distributions/gradle-5.4-bin.zip

Build the complete project using Gradle and check jar created under build/libs then run the Docker commands


Note:
For entrypoint.sh not found issue ,please save file as UNIX (In Notepad++,Edit --EOL conversion -- Unix)

To check swagger 
---------------------------
http://localhost:8080/swagger-ui.html